package model;

public interface LibraryInterface 
{
	    int PATRONBAG_MAXSIZE = 200000;	
	    int TRANSACTIONBAG_MAXSIZE = 10;
}
